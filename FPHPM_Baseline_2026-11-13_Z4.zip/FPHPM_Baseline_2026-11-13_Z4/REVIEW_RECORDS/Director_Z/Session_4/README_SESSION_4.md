# Director Z, fourth session | Histories as events, the order of the pair rule, forces from gains of bounded order, the remainder of the ray; paper G10

13 November 2026. Research direction: Kirtus Justus. Reviewing participant: LLM Director Z, Claude (Anthropic), at the principal's direction; no endorsement by Anthropic is implied. One participant in this stack; every challenge inside it is a self-check. Root Unary Review of the program whole: G1 Grounding, OPEN, unchanged. No ontology is selected.

| File | Content |
|---|---|
| `CALIBRATION_AND_ACR_USE_LOG_SESSION_4.md` | onboarding, what was and was not established about the method, the Calibration Record, intake checks, direction of the stack, use log |
| `reports/DIRECTOR_Z_TECHNICAL_DISPOSITION_SESSION_4.md` | assessments, evidence, dispositions |
| `registers/NEW_Z_SCOPED_FINDINGS_SESSION_4.csv` | fourteen scoped findings, Z-041 to Z-054 |
| `registers/CALIBRATION_RECORD_SESSION_4.json`, `CALIBRATION_RETRIEVAL_ANSWERS_SESSION_4.json`, `CALIBRATION_RETRIEVAL_SCORES_SESSION_4.json` | the Calibration Record (Core 14.4, build 22), the committed answers and their mechanical scores |
| `sources/SOURCE_LEDGER_SESSION_4.md` | external sources retrieved, with digests and the portions read |
| `register/register.jsonl`, `register/artifacts/` | the append-only register kept for this session by the PCP OS program (`pcpos` 1.0.22), with the principal's opening message as kept by the program |
| `CHANGES_Z3_TO_Z4.md` | every file added or changed |

The register: 37 events; head digest of the chain `ea97886d0cc8dcd7aba4d95f9844cc8c95f312e56c4796f8da0d5123e1b250d8`; SHA-256 of the file `6862457fbd2565882024348639c109bb4522ef865f3eadf078f48d0413312f89`. Check it with `pcpos verify register/register.jsonl`, which prints the head digest of the chain and replays the guards. A pass is a fact about those bytes. The adoption in it is recorded as relayed by the participant, because the program was reached through a client written in the session and no host hook observed the principal's message; its status therefore carries one standing attention item asking the person to confirm. The checks in it are the participant's reports.

The manuscript produced is paper G10 (`PAPERS/G10_Histories_as_Events_the_Order_of_the_Pair_Rule_First_Order_Weights_an`). Papers G7, G8 and G9 are unchanged.
